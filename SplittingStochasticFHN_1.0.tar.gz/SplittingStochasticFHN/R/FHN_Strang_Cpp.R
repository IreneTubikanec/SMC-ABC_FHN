FHN_Strang_Cpp <- function(grid, h, startv, dm, cm, eps, beta){
  return(FHN_Strang_Cpp_(grid, h, startv, dm, cm, eps, beta))
}
